These files are modifed version of 45552 downloaded from
http://scintillanet.codeplex.com/SourceControl/changeset/view/45552
which addressed the following problems:

Snippet compilation problem:
http://scintillanet.codeplex.com/WorkItem/View.aspx?WorkItemId=24757

Improving performance of creating ScintillaNet controls:
http://scintillanet.codeplex.com/WorkItem/View.aspx?WorkItemId=24671
